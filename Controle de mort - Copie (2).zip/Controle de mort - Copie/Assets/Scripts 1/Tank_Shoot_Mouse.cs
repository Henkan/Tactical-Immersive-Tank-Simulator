﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank_Shoot_Mouse : MonoBehaviour {
    private bool cpt = false;
    public float x = 0;
    public float maxbulletreload = 1;
    private float bulletreload = 1;
    public int ejectspeed = 10;
    private Rigidbody bullet;
    public Rigidbody bulletCasing;
    public GameObject viseur;
    public GameObject canon;
    private GameObject light;
    public GameObject light_model;
    public Transform parent;
    public float correcty = 0.0f;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButtonDown("Fire1") && cpt == false)
        {
            Vector3 posLumiere = viseur.transform.position;
            posLumiere.z += 0.3f;
            light = Instantiate(light_model, posLumiere, viseur.transform.rotation);
            light.transform.SetParent(parent);
            Destroy(light, 0.1f);
            Quaternion bulletRot = canon.transform.rotation;
            bulletRot.eulerAngles = new Vector3(canon.transform.rotation.eulerAngles.x, canon.transform.rotation.eulerAngles.y + correcty, canon.transform.rotation.eulerAngles.z);

            bullet = Instantiate(bulletCasing, viseur.transform.position, bulletRot);
            bullet.velocity = bullet.transform.TransformDirection(Vector3.left * ejectspeed);
            bullet.tag = "bullet";



            cpt = true;
            bulletreload = maxbulletreload;



        }

        if (cpt == true)
        {
            bulletreload -= 1 * Time.deltaTime;
        }
        if (bulletreload <= 0)
        {
            cpt = false;
        }
    }
}
