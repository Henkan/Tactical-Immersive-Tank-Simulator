﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Rotation_Auto : MonoBehaviour {

    public Transform target;
    
    Plane ground;
    public float speed = 10.0f;
    public float correctz = 0.0f;

    // Use this for initialization
    void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {


        /*ground = new Plane(Vector3.up, transform.position);

        Ray ray = Camera.main.ScreenPointToRay(target.position);
        float dist = 0.0f;
        if (ground.Raycast(ray, out dist))
        {
            Vector3 clickPoint = new Vector3(ray.GetPoint(dist).x, transform.position.y + 90, ray.GetPoint(dist).z);

            Quaternion targetRotation = Quaternion.LookRotation(clickPoint - transform.position);

            targetRotation.eulerAngles = new Vector3(targetRotation.eulerAngles.x, targetRotation.eulerAngles.y + 90, targetRotation.eulerAngles.z + correctz);

            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, speed * Time.deltaTime);
        }*/
        if (target != null)
        {
            transform.LookAt(target);
            transform.rotation = Quaternion.Euler(-90, transform.eulerAngles.y + 180, transform.eulerAngles.z);
        }
    }
}
