﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank_Shoot2Chaise : MonoBehaviour {

    private bool cpt = false;
    public float x = 0;
    public float maxbulletreload = 1;
    private float bulletreload = 1;
    public int ejectspeed = 10;
    private Rigidbody bullet;
    public Rigidbody bulletCasing;
    public GameObject viseur;
    private GameObject light;
    public GameObject light_model;
    public Transform parent;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetButtonDown("Fire12") && cpt == false)
        {
            light = Instantiate(light_model, viseur.transform.position, viseur.transform.rotation);
            light.transform.SetParent(parent);
            Destroy(light, 0.1f);
            bullet = Instantiate(bulletCasing, viseur.transform.position, viseur.transform.rotation);
            bullet.velocity = transform.TransformDirection(Vector3.forward * ejectspeed);
            bullet.tag = "bullet2";
            cpt = true;
            bulletreload = maxbulletreload;
            transform.GetChild(0).GetComponent<Animator>().SetBool("tirer", true);
        }
        else
        {
            transform.GetChild(0).GetComponent<Animator>().SetBool("tirer", false);
        }

        if (cpt == true)
        {
            bulletreload -= 1 * Time.deltaTime;
        }
        if (bulletreload <= 0)
        {
            cpt = false;
        }
    }
}
