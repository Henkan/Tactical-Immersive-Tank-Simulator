﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deplacementTankJ2Chaise : MonoBehaviour {

    public int speed = 10;
    public int turnSpeed = 10;
    public int life = 100;
    public GameObject missile;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        this.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        transform.position = new Vector3(transform.position.x, 0.30f, transform.position.z);
        if (Input.GetAxisRaw("Vertical2") > 0)
        {
            this.transform.Translate(0, 0, speed * Time.deltaTime);
        }
        if (Input.GetAxisRaw("Vertical2") < 0)
        {
            this.transform.Translate(0, 0, -speed * Time.deltaTime);
        }
        if (Input.GetAxisRaw("Horizontal2") < 0)
        {
            //transform.rotation = Quaternion.Euler(0, -10, 0);
            transform.Rotate(Vector3.up, -turnSpeed * Time.deltaTime);
        }
        if (Input.GetAxisRaw("Horizontal2") > 0)
        {
            transform.Rotate(Vector3.up, turnSpeed * Time.deltaTime);
        }
    }

    void OnCollisionEnter(Collision hit)
    {
        if (hit.gameObject.tag == "bullet")
        {
            life -= 10;
            Destroy(hit.gameObject);
        }
    }
}
