﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class PathFinding : MonoBehaviour {

    public Transform target;
    NavMeshAgent agent;
    private float distance;
    private bool cpt = false;
    public float maxbulletreload = 1;
    private float bulletreload = 1;
    public int ejectspeed = 10;
    private Rigidbody bullet;
    public Rigidbody bulletCasing;
    public GameObject viseur;
    public GameObject canon;
    private GameObject light;
    public GameObject light_model;
    public Transform parent;
    public float correcty = 0.0f;
    public int life = 150;
    

    // Use this for initialization
    void Start () {
        agent = GetComponent<NavMeshAgent>();
	}
	
	// Update is called once per frame
	void Update () {
        this.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        transform.position = new Vector3(transform.position.x, 0.30f, transform.position.z);
        if (target != null)
        {
            agent.SetDestination(target.position);


            distance = Vector3.Distance(target.position, transform.position);

            if (distance <= 6 && cpt == false)
            {
                Vector3 posLumiere = viseur.transform.position;
                posLumiere.z += 0.3f;
                light = Instantiate(light_model, posLumiere, viseur.transform.rotation);
                light.transform.SetParent(parent);
                Destroy(light, 0.1f);
                Quaternion bulletRot = canon.transform.rotation;

                bulletRot.eulerAngles = new Vector3(canon.transform.rotation.eulerAngles.x, canon.transform.rotation.eulerAngles.y + correcty, canon.transform.rotation.eulerAngles.z);

                bullet = Instantiate(bulletCasing, viseur.transform.position, bulletRot);
                bullet.velocity = bullet.transform.TransformDirection(Vector3.left * ejectspeed);
                bullet.tag = "bullet2";



                cpt = true;
                bulletreload = maxbulletreload;



            }

            if (cpt == true)
            {
                bulletreload -= 1 * Time.deltaTime;
            }
            if (bulletreload <= 0)
            {
                cpt = false;
            }
        }
    

	}
    void OnCollisionEnter(Collision hit)
    {
        if (hit.gameObject.tag == "bullet")
        {
            life -= 10;
            Destroy(hit.gameObject);
            if (this.life <= 0)
            {
                GameObject tank = this.gameObject;
                Destroy(tank);
            }

        }
    }
}
