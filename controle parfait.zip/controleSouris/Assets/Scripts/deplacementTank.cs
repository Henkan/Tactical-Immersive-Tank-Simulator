﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deplacementTank : MonoBehaviour {

    public int speed = 10;
    public int turnSpeed = 10;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKey("up"))
        {
            this.transform.Translate(0, 0, speed*Time.deltaTime);
        }
        if (Input.GetKey("down"))
        {
            this.transform.Translate(0, 0, -speed * Time.deltaTime);
        }
        if (Input.GetKey("left"))
        {
            //transform.rotation = Quaternion.Euler(0, -10, 0);
            transform.Rotate(Vector3.up, -turnSpeed * Time.deltaTime);
        }
        if (Input.GetKey("right"))
        {
            transform.Rotate(Vector3.up, turnSpeed * Time.deltaTime);
        }
    }
}
