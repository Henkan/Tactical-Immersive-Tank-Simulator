﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank_Shoot_Mouse : MonoBehaviour {
    private bool cpt = false;
    public float x = 0;
    public float maxbulletreload = 1;
    private float bulletreload = 1;
    public int ejectspeed = 10;
    private Rigidbody bullet;
    public Rigidbody bulletCasing;
    public GameObject viseur;
    public GameObject canon;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButtonDown("Fire1") && cpt == false)
        {
            bullet = Instantiate(bulletCasing, viseur.transform.position, canon.transform.rotation);
            bullet.velocity = bullet.transform.TransformDirection(Vector3.left * ejectspeed);
            bullet.tag = "bullet";



            cpt = true;
            bulletreload = maxbulletreload;



        }

        if (cpt == true)
        {
            bulletreload -= 1 * Time.deltaTime;
        }
        if (bulletreload <= 0)
        {
            cpt = false;
        }
    }
}
