﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collisionBullet : MonoBehaviour {
    public int collisionCounter = 0;
	// Use this for initialization
	void Start () {
        Destroy(this.gameObject, 3);
	}
	
	// Update is called once per frame
	void Update () {
		if(collisionCounter >= 3)
        {
            Destroy(this.gameObject);
        }
	}

    void OnCollisionEnter(Collision hit)
    {
        collisionCounter+=1;
    }
}
