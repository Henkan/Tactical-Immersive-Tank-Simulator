﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank_Shoot : MonoBehaviour {
    private bool cpt = false;
    public float x=0;
    public float maxbulletreload = 1;
    private float bulletreload = 1;
    private int ejectspeed = 50;
    private Rigidbody bullet;
    public Rigidbody bulletCasing;






    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        
        //sphere.transform.Translate(Vector3.back * 60 * Time.deltaTime);

        if (Input.GetKey("space") && cpt == false)
            {
            /*GameObject bullet = GameObject.CreatePrimitive(PrimitiveType.Sphere);

            x = 0;
            bullet.transform.position = new Vector3(GameObject.Find("viseur").transform.position.x, GameObject.Find("viseur").transform.position.y , GameObject.Find("viseur").transform.position.z - 0.75F);
            */
            bullet = Instantiate(bulletCasing, GameObject.Find("viseur").transform.position, GameObject.Find("viseur").transform.rotation);
                bullet.velocity = transform.TransformDirection(Vector3.back * ejectspeed);

                

                cpt = true;
            bulletreload = maxbulletreload;

               
           
            }
        
        if (cpt == true)
        {
            bulletreload -= 1 * Time.deltaTime;
        }
        if(bulletreload <= 0)
        {
            cpt = false;
        }



        


    }

}
