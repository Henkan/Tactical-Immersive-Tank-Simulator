﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collisionBullet : MonoBehaviour {
    public int collisionCounter = 0;
    private GameObject light;
    public GameObject light_model;

    // Use this for initialization
    void Start () {
        Destroy(this.gameObject, 3);
	}
	
	// Update is called once per frame
	void Update () {
        this.gameObject.transform.position = new Vector3(transform.position.x, GameObject.Find("viseur").transform.position.y-0.03f, transform.position.z);
		if(collisionCounter >= 3)
        {
            Destroy(this.gameObject);
        }
	}

    void OnCollisionEnter(Collision hit)
    {
        collisionCounter+=1;
        light = Instantiate(light_model, this.transform.position, this.transform.rotation);
        Destroy(light, 0.1f);
    }
}
