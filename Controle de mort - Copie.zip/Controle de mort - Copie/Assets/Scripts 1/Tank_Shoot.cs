﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank_Shoot : MonoBehaviour {
    private bool cpt = false;
    public float x=0;
    public float maxbulletreload = 1;
    private float bulletreload = 1;
    public int ejectspeed = 10;
    private Rigidbody bullet;
    public Rigidbody bulletCasing;
    public GameObject viseur;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        
        //sphere.transform.Translate(Vector3.back * 60 * Time.deltaTime);

        if (Input.GetButtonDown("Fire1") && cpt == false)
            {
            /*GameObject bullet = GameObject.CreatePrimitive(PrimitiveType.Sphere);

            x = 0;
            bullet.transform.position = new Vector3(GameObject.Find("viseur").transform.position.x, GameObject.Find("viseur").transform.position.y , GameObject.Find("viseur").transform.position.z - 0.75F);
            */
            bullet = Instantiate(bulletCasing, viseur.transform.position, viseur.transform.rotation);
                bullet.velocity = transform.TransformDirection(Vector3.forward * ejectspeed);
            bullet.tag = "bullet";



            cpt = true;
            bulletreload = maxbulletreload;

               
           
            }
        
        if (cpt == true)
        {
            bulletreload -= 1 * Time.deltaTime;
        }
        if(bulletreload <= 0)
        {
            cpt = false;
        }

    }

}
