﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Tank_Move : MonoBehaviour {

    public int speed = 10;
    public int life = 100;
    public float correctz = 0.0f;

	// Use this for initialization
	void Start () {

    }
	
	// Update is called once per frame
	void Update () {
        Move();

        
        
    }

    private void Move()
    {
        this.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        if (Input.GetAxisRaw("Vertical") > 0 && Input.GetAxisRaw("Horizontal") < 0)
        {
            transform.Translate(Vector3.forward * speed / 2 * Time.deltaTime);
            transform.Translate(Vector3.left * speed / 2 * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 135, 90+correctz);
        }
        else if (Input.GetAxisRaw("Vertical") > 0 && Input.GetAxisRaw("Horizontal") > 0)
        {
            transform.Translate(Vector3.forward * speed / 2 * Time.deltaTime);
            transform.Translate(Vector3.right * speed / 2 * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 45, 90 + correctz);
        }
        else if (Input.GetAxisRaw("Vertical") < 0 && Input.GetAxisRaw("Horizontal") < 0)
        {
            transform.Translate(Vector3.back * speed / 2 * Time.deltaTime);
            transform.Translate(Vector3.left * speed / 2 * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 45, 90 + correctz);
        }
        else if (Input.GetAxisRaw("Vertical") < 0 && Input.GetAxisRaw("Horizontal") > 0)
        {
            transform.Translate(Vector3.back * speed / 2 * Time.deltaTime);
            transform.Translate(Vector3.right * speed / 2 * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, -45, 90 + correctz);
        }
        else if (Input.GetAxisRaw("Vertical") < 0)
        {
            transform.Translate(Vector3.back * speed * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 0, 90 + correctz);
        }
        else if (Input.GetAxisRaw("Vertical") > 0)
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 180, 90 + correctz);
        }
        else if (Input.GetAxisRaw("Horizontal") < 0)
        {
            transform.Translate(Vector3.left * speed * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 90, 90 + correctz);
        }
        else if (Input.GetAxisRaw("Horizontal") > 0)
        {
            transform.Translate(Vector3.right * speed * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, -90, 90 + correctz);
        }
    }

    void OnCollisionEnter(Collision hit)
    {
        if (hit.gameObject.tag == "bullet2" || hit.gameObject.tag == "bullet")
        {
            life -= 10;
            Destroy(hit.gameObject);
            if (this.life <= 0)
            {
                GameObject tank =this.gameObject;
                Destroy(tank);
            }
                
        }
    }

}
