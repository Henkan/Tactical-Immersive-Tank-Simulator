﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotationSouris : MonoBehaviour {


    public float speed = 10.0f;
    public float correctz = 0.0f;

    Plane ground;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        ground = new Plane(Vector3.up, transform.position);

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        float dist = 0.0f;

        if(ground.Raycast(ray, out dist))
        {
            Vector3 clickPoint = new Vector3(ray.GetPoint(dist).x, transform.position.y+90, ray.GetPoint(dist).z);

            Quaternion targetRotation = Quaternion.LookRotation(clickPoint - transform.position);

            targetRotation.eulerAngles = new Vector3(targetRotation.eulerAngles.x, targetRotation.eulerAngles.y+90, targetRotation.eulerAngles.z+correctz);

            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, speed * Time.deltaTime);
        }
    }
}
