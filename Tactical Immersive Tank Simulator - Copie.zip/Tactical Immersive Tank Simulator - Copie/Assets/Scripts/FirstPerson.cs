﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPerson : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey("space"))
        {
            transform.position= GameObject.Find("FirstTank").transform.position;
            transform.Rotate(0, 180, 0);
            transform.position = new Vector3(GameObject.Find("Main Camera").transform.position.x, GameObject.Find("Main Camera").transform.position.y + 5, GameObject.Find("Main Camera").transform.position.z);
        }

    }
}
