﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Tank_Move : MonoBehaviour {

    public int speed = 10;
    public int rotation_speed = 90;
    public double angle_canon;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey("up") && Input.GetKey("left"))
        {
            transform.Translate(Vector3.forward * speed/2 * Time.deltaTime);
            transform.Translate(Vector3.left * speed/2 * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 135, 90);
        }
        else if (Input.GetKey("up") && Input.GetKey("right"))
        {
            transform.Translate(Vector3.forward * speed / 2 * Time.deltaTime);
            transform.Translate(Vector3.right * speed / 2 * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 45, 90);
        }
        else if (Input.GetKey("down") && Input.GetKey("left"))
        {
            transform.Translate(Vector3.back * speed / 2 * Time.deltaTime);
            transform.Translate(Vector3.left * speed / 2 * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 45, 90);
        }
        else if (Input.GetKey("down") && Input.GetKey("right"))
        {
            transform.Translate(Vector3.back * speed / 2 * Time.deltaTime);
            transform.Translate(Vector3.right * speed / 2 * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, -45, 90);
        }
        else if (Input.GetKey("down"))
        {
            transform.Translate(Vector3.back * speed * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 0, 90);
        }
        else if (Input.GetKey("up"))
        {
            transform.Translate(Vector3.forward * speed * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 180, 90);
        }
        else if (Input.GetKey("left"))
        {
            transform.Translate(Vector3.left * speed * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, 90, 90);
        }
        else if (Input.GetKey("right"))
        {
            transform.Translate(Vector3.right * speed * Time.deltaTime);
            transform.GetChild(0).eulerAngles = new Vector3(-90, -90, 90);
        }
        //direction_x_canon = Math.Cos((Input.mousePosition.x - GameObject.Find("GameObject").transform.position.x)/((Math.Sqrt(Math.Pow(Input.mousePosition.x - GameObject.Find("GameObject").transform.position.x,2))+(Input.mousePosition.x - GameObject.Find("GameObject").transform.position.x) / Math.Pow((Math.Sqrt(Input.mousePosition.y - GameObject.Find("GameObject").transform.position.y)),2))));
        angle_canon = Math.Atan((Input.mousePosition.y - GameObject.Find("GameObject").transform.position.y)/(Input.mousePosition.x - GameObject.Find("GameObject").transform.position.x));
        transform.GetChild(1).eulerAngles = new Vector3(-90, (float)(angle_canon*180)/(float)Math.PI, 90);


    }
}
