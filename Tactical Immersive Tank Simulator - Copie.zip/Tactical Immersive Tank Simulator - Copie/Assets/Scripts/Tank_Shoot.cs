﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank_Shoot : MonoBehaviour {



	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey("space"))
        {
            GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            sphere.transform.position = new Vector3(GameObject.Find("GameObject").transform.position.x, GameObject.Find("GameObject").transform.position.y + 2.25F, GameObject.Find("GameObject").transform.position.z - 5);
        }
	}
}
