﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Move : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.position = ((new Vector3(GameObject.Find("GameObject").transform.position.x-1.5f, GameObject.Find("GameObject").transform.position.y + 48f, GameObject.Find("GameObject").transform.position.z-20.9F)));
    }
}
