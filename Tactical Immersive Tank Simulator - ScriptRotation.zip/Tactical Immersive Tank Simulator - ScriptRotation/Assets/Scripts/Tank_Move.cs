﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank_Move : MonoBehaviour {

    public long speed = 10;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey("down"))
        {
            transform.Translate(Vector3.back * speed * Time.deltaTime);
			transform.GetChild(0).transform.eulerAngles = new Vector3(-90, 0, -90);
        }
        else if (Input.GetKey("up"))
        {
			transform.Translate(Vector3.forward * speed * Time.deltaTime);
			transform.GetChild(0).transform.eulerAngles = new Vector3(-90, 0, 90);
        }
        if (Input.GetKey("left"))
        {
            transform.Translate(Vector3.left * speed * Time.deltaTime);
			transform.GetChild(0).transform.eulerAngles = new Vector3(-90, 0, 0);
        }
        else if (Input.GetKey("right"))
        {
			transform.Translate(Vector3.right * speed * Time.deltaTime);
			transform.GetChild(0).transform.eulerAngles = new Vector3(-90, 0, 180);
        }
    }
}
